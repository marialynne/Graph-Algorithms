/*
 * meetinthemiddle.cpp
 * Programa que implementa una solución al problema de Meet in the Middle.
 * El programa recibe como entrada un numero n equivalente a una suma maxima, asi como una lista de enteros.
 * Se da solucion al problema al encontrar la suma los subconjuntos de la lista de enteros de entrada. 
 * El resultado debe debe ser igual o menor a la suma maxima.
 * Fecha: 16/11/2022
 * Complejidad: O(2^n)
 * Autores:
 *          Carla Onate Gardella
 *          Manuel Camacho Padilla
 *          Octavio Augusto Aleman Esparza
 */
#include <iostream>
#include <vector>
#include <regex>
#include <sstream>

using namespace std;

vector<vector<double>> firtSubset;
vector<vector<double>> secondSubset;
void findSubsets(vector<double> originList, vector<double> outList, int index, int size, double sum, double max, int key)
{
    if(index < size && sum <= max)
    {
        findSubsets(originList, outList, index + 1, size, sum, max, key);
        outList.push_back(originList[index]);
        findSubsets(originList, outList, index + 1, size, sum + originList[index], max, key);
    }
    else if(index <= size && sum <= max)
    {
        if(key == 1)
        {
            firtSubset.push_back(outList);
        }
        else{
            secondSubset.push_back(outList);
        }
    }
}

double returnValue(vector<double> subset)
{
    double sum;
    for(int i = 0; i < subset.size(); i++)
    {
        sum += subset[i];
    }
    return sum;
}

void meetInTheMiddle(vector<double> list, double n)
{
    int half = list.size() / 2;
    vector<double> lowerHalf(list.begin(), list.begin() + half);
    vector<double> upperHalf(list.begin() + half, list.end());

    vector<double> outList;

    findSubsets(lowerHalf, outList, 0, lowerHalf.size(), 0, n, 1);
    findSubsets(upperHalf, outList, 0, upperHalf.size(), 0, n, 2);

    double maxSum = 0;
    vector<vector<double>> maxSumSubsets;

    for(int i = 0; i < firtSubset.size(); i++)
    {
        for(int j = i; j < secondSubset.size(); j++)
        {
            double firstSum = returnValue(firtSubset[i]);
            double secondSum = returnValue(secondSubset[j]);
            if(firstSum > maxSum  && firstSum <= n)
            {
                maxSumSubsets.clear();
                maxSumSubsets.push_back(firtSubset[i]);
                maxSum = firstSum;
            }
            if(secondSum > maxSum  && secondSum <= n)
            {
                maxSumSubsets.clear();
                maxSumSubsets.push_back(secondSubset[j]);
                maxSum = secondSum;
            }
            if((firstSum + secondSum) > maxSum && (firstSum + secondSum) <= n)
            {
                maxSumSubsets.clear();
                maxSumSubsets.push_back(firtSubset[i]);
                maxSumSubsets.push_back(secondSubset[j]);
                maxSum = firstSum + secondSum;
            }
        }
    }

    cout<<"Output: "<<maxSum<<"\n";
    cout<<"La suma maxima del subconjunto es "<<maxSum<<", la cual se obtiene de los numeros: ";

    for(int i = 0; i < maxSumSubsets[0].size(); i++)
    {
        cout<<" -> "<<maxSumSubsets[0][i];
    }

    for(int i = 0; i < maxSumSubsets[1].size(); i++)
    {
        cout<<" -> "<<maxSumSubsets[1][i];
    }
}

bool regexNumber(string numb) // Time: O(1)
{
    const regex expReg("^[0-9]+$");
    return regex_match(numb, expReg);
}

void init()
{
    cout<<"Bienvenido a Meet in The Middle\n";

    string n;

    while(true)
    {
        cout<<"Ingrese suma maxima: ";
        cin >> n;

        if(!regexNumber(n))
        {
            cout<<"ERROR: Entrada invalida.\n";
        }else if(stod(n) <= 1  && regexNumber(n))
        {
            cout<<"ERROR: La suma maxima debe ser mayor a 1.\n";
        }else
        {
            break;
        }
    }

    //vector<int> list = {45, 34, 4, 12, 5, 2};
    vector<double> list;
    string input;

    //double maxPossible = (10 ^ 12);

    cin.ignore();
    for(int j = 0; j < 1; j++)
    {
        cout<<"Ingrese input set: ";
        getline(cin, input);

        stringstream ss(input);
        for (string i; ss >> i;)
        {
        if (regexNumber(i))
        {
            if(stod(i) < 1 )//|| stod(i) > maxPossible)
            {
                cout << "ERROR: Valores de entrada deben ser 1 <= v < 10 ^ 12.\n";
                list.clear();
                j--;
            }
            else
            {
                list.push_back(stod(i));
            }
        }
        else
        {
            cout << "ERROR: Entrada no valida.\n";
            list.clear();
            j--;
        }
        }

        if(list.empty() && j == 0)
        {
            cout<<"ERROR: No se aceptan entradas vacias.\n";
            j--;
        }
        cout<<"\n";
    }

    meetInTheMiddle(list, stod(n));
}

int main()
{
    init();
}